package peaksoft.model.enums;

public enum StudyFormat {

        ONLINE,OFFLINE

}
